#ifndef _ANALYSIS_H
#define _ANALYSIS_H

int     analysis_module( const u_char *packet_content );

#endif
